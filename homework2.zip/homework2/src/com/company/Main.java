package com.company;

public class Main {

    public static void main(String[] args) {
        String name =
        int temp = 35 ;
        int age = 30 ;
        if (temp<30 ||  temp > -20 && age>20  && age<45) {
            System.out.println("Иду в гости к другу");
        } else if (age<20 && temp>0 && temp <28){
            System.out.println("Иду в гости к другу");
        }
        else if (age<45 && temp>-10 && temp <25){
            System.out.println("Иду в гости к другу");
        }
        else {
            System.out.println("Не иду гулять");
        }

        }
    }

